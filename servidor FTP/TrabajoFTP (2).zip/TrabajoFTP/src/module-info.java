module TrabajoFTP {
	requires java.rmi;
	 exports v0;
}